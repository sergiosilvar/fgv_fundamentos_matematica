'''
Created on 27/01/2013

@author: sergio
'''

class MyClass():
    '''
    classdocs
    '''


    def __init__(self,x0,y0,lado):
        '''
        Constructor
        '''
        self.x0 = x0
        self.y0 = y0
        self.lado = lado
        