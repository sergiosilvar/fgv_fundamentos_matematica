'''
Created on 29/01/2013

@author: sergio
'''

def lista_subconjunto(conj):
    if len(conj)==1:
        return str(conj)
if __name__ == '__main__':
    x=0
    for i in range(1,124):
        for j in range(1,i+1):
            x += 1
    print x   
    print "FIM DO PROGRAMA"